from sqlite3 import DatabaseError
import streamlit as st
import pandas as pd
import numpy as np 
import regex as re
import nltk
import gensim
import tensorflow as tf
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.metrics import confusion_matrix

menu = ['Beranda','Data Preprocessing', 'Word Embedding', 'Pelatihan Model', 'Clickbait Detection']

option = st.sidebar.selectbox("Menu", menu)

if option == 'Beranda' or option == '':
    st.title("""Beranda""") #menampilkan halaman utama
    st.header("""Abstrak """) #menampilkan halaman utama

    st.write("Teknologi informasi terus berkembang dan memberi perubahan pada manusia dalam mendapatkan informasi, salah satunya dengan adanya portal berita online. Namun portal berita online saat ini tidak hanya menjadi sarana dalam membagikan informasi faktual, tetapi juga menjadi sebuah bisnis. Banyak strategi yang digunakan untuk meningkatkan pengunjung dan traffic dari situs berita, salah satunya dengan memberi judul artikel yang menjebak (clickbait). Pada pemberitaan mengenai COVID-19, tak sedikit informasi simpang siur beredar dikarenakan judul artikel clickbait. Masalah tersebut menjadi salah satu penghalang Indonesia untuk mengurangi kasus COVID-19. Hal ini yang menjadi motivasi dasar pada penelitian untuk membuat program deteksi berita clickbait artikel COVID-19 pada portal berita terbesar di Indonesia, yaitu Okezone.com.")
    st.write("Metode penelitian dalam penelitian ini mengandalkan teknik Natural Language Processing (NLP) dan kecerdasan artifisial, dengan menggabungkan word embedding Word2vec dan Bidirectional Long-Short Term Memory (Bi-LSTM). Data yang sudah dikumpulkan diklasifikasikan ke dalam dua kelas, lalu dilakukan pengujian ke dalam dua model Bi-LSTM, dan terakhir melakukan uji hyperparameter untuk mendapatkan model yang paling optimal. Model Bi-LSTM yang terbaik didapat yaitu Bi-LSTM dengan CNN dan cosine similarity. Dalam uji hyperparameter menghasilkan kondisi optimal ketika hyperparameter Word2vec meliputi dimensi sebesar 200 dan ukuran window 5, dan untuk Bi-LSTM, ketika terdiri dari 2 lapisan, optimizernya adalah adamax, nilai dropout 0,3, dan ukuran batch size-nya 32. Kondisi optimal ini jika dievaluasi menggunakan confusion matrix menghasilkan rata rata akurasi dan f1-score masing-masing 88%.")
    st.write("Kata Kunci : Clickbait, Word2Vec, Bidirectional Long-Short Term Memory, Okezone, COVID-19")

elif option == 'Data Preprocessing':
    st.title("""Data Preprocessing""") #menampilkan judul halaman 

    st.header("""Informasi Data""")
    st.markdown("""
    <ul>
        <li>Sumber Data berasal dari portal berita online Okezone.com dengan tag "COVID-19"</li>
        <li>Data dikumpulkan dari tanggal 30 November 2021-24 Februari 2022</li>
        <li>Jumlah data berjumlah 3519, dengan 781 data berlabel "clickbait" dan 2738 data berlabel "non-clickbait"</li>
    </ul>""",  unsafe_allow_html=True)

    st.header("""Data Asli""") #menampilkan judul halaman 

    #membuat dataframe dengan pandas yang terdiri dari 2 kolom dan 4 baris data
    df = pd.read_csv('Data Skripsi Anne NoTgl.csv', encoding="latin-1")
    df #menampilkan dataframe


    st.header("""Data Hasil Preprocessing""") #menampilkan judul halaman 

    st.write("Berikut merupakan data yang digunakan dan telah dilakukan preprocessing oleh penulis saat penelitian")

    #membuat dataframe dengan pandas yang terdiri dari 2 kolom dan 4 baris data
    df = pd.read_csv('Okezone_Clean_Update3.csv')
    df #menampilkan dataframe

    st.header("Uji Text Preprocessing")
    title = st.text_input('Masukkan Teks yang Ingin Di Preprocessing Disini ⬇️', '')
    
    st.write("1. Case Folding")
    text = title.lower()

    st.write('Hasil Case Folding : ', text)

    st.write("2. Cleaning Text")

    def cleaning_text(text):
        # Menghilangkan baris baru, tab, underline.
        text = text.replace('\\t'," ").replace('\\n'," ").replace('\\u'," ").replace('\\',"")
        # Remove Punctuation 
        text = re.sub(r'[^\w\s]', '', text)
        # # Ambil 3 Kalimat
        # text = ' '.join(re.split(r'(?<=[.:;])\s', text)[:3])
        # Menghilangkan simbol emoticon dan huruf selain ascii
        text = text.encode('ascii', 'replace').decode('ascii')
        # Menghapus mention (@), link, dan hashtag
        text = ' '.join(re.sub("([@#][A-Za-z0-9]+)|(\w+:\/\/\S+)"," ", text).split())
        # remove_empty_space
        text = re.sub(r'', '', text.strip())
        # remove number
        text = re.sub("\d+", "", text)
        #remove multiple space
        text = re.sub(r'\s\s+', ' ', text)
        # remove incomplete URL
        return text.replace("http://", " ").replace("https://", " ")

    st.write("Hasil Cleaning Text :", cleaning_text(text))
    text = cleaning_text(text)

    st.write("3. Tokenization")

    def tokenization(text):
        text = re.split('\W+', text)
        return text

    st.write("Hasil Tokenization :", tokenization(text))
    text = tokenization(text)

    st.write ("4. Remove Stopword")

    def remove_stopwords(text):
        stopword = nltk.corpus.stopwords.words('indonesian')
        stopword = [e for e in stopword if e not in ('akankah', 'apa', 'apakah', 'bagaimana', 'bagaimanakah', 'beberapa', 'begini', 'beginilah', 'benarkah', 'berapa', 'berapakah', 'berikut', 'bisakah', 'bolehkah', 'cara', 'hal', 'ini', 'inikah', 'inilah', 'kapan', 'kapankah', 'kok', 'mengapa', 'menurut', 'mungkinkah', 'pentingnya', 'siapa', 'siapakah', 'waduh', 'wah')]
        text = [word for word in text if word not in stopword]
        return text

    st.write("Hasil Remove Stopword : ", remove_stopwords(text))
    text = " ".join(remove_stopwords(text))

    # df = pd.DataFrame({'input':text}, ignore_index=True)

    st.write("5. Stemming Data")
    
    factory = StemmerFactory()
    stemmer = factory.create_stemmer()

    # stemmed
    def stemmed_wrapper(text):
        return stemmer.stem(text)

    st.write("Hasil Stemming : ", stemmed_wrapper(text))


elif option == 'Word Embedding':
    st.title("""Word Embedding Word2Vec""") #menampilkan judul halaman 
    st.header("""Hyperparameter yang digunakan""")

    st.markdown(
    """
    <ul>
        <li>Ukuran Dimensi : 200 (Dimensi Kata Vektor)</li>
        <li>Ukuran Window : 5 (jarak antara kata-kata konteks dengan posisi kata yang menjadi inputan)</li>
    </ul>
    """, unsafe_allow_html=True)
    
    path = 'idwiki_word2vec200.model'
    id_w2v = gensim.models.word2vec.Word2Vec.load(path)
    # w2v_model = gensim.models.Word2Vec(sentences=X, vector_size=DIM, window=5, min_count=1)

    st.write("Contoh Menampilkan Vektor pada Kata 'Omicron' \n", id_w2v.wv['omicron'])

    st.markdown(
    """
    <h2 class="title">Uji Mencari Keterkaitan (Hubungan Semantik) antar kata dengan Word2vec</h1>
    """, unsafe_allow_html=True)
    word2vec = st.text_input('Masukan satu kata: ', '',key=0)
    word2vec = word2vec.lower()
    if st.button("Submit",key=0):
        st.text("Keterkaitan antar kata '" + word2vec + "' adalah :")
        # st.text("lima Kata yang paling mirip dengan : ",word2vec)
        st.dataframe(id_w2v.wv.most_similar(word2vec, topn = 5))
        st.text("Vektor pada kata '" + word2vec + "' adalah :")
        st.write(id_w2v.wv[word2vec])


elif option == 'Pelatihan Model':
    st.title("""Pelatihan Model""") #menampilkan judul halaman
    st.header("""Skema Pelatihan Model""")
    st.markdown(
    """
    <ul>
        <li>Datanya merupakan data tak imbang sehingga dilakukan penyamaan class data menggunakan SMOTE</li>
        <li>Percobaan dilakukan dengan mengombinasikan Bi-LSTM dengan Cosine Similarity dan Cosine Similarity + CNN</li>
        <li>Dari hasil percobaan diatas, ditemukan hasil Bi-LSTM dengan Cosine dan CNN memberikan nilai yang lebih baik</li>
        <li>Dilanjutkan dengan uji coba hyperparameter, seperti dimensi dan window size pada Word2Vec, lalu Jumlah lapisan, jenis optimizer, jumlah batch size, dll pada Bi-LSTM</li>
    </ul>
    """, unsafe_allow_html=True)

    st.header("Hasil Percobaan Hyperparameter")
    st.markdown(
    """
    <table>
        <tr>
            <td colspan='2'>Word2Vec</td>
            <td colspan='4'>Bi-LSTM</td>
            <td rowspan = '2'>Accuracy</td>
            <td rowspan='2'>F1-Score</td>
        </tr>
        <tr>
            <td>Dimensi</td>
            <td>Window Size</td>
            <td>Lapisan</td>
            <td>Dropout</td>
            <td>Optimizer</td>
            <td>Batch Size</td>
        </tr>
        <tr>
            <td>200</td>
            <td>5</td>
            <td>2</td>
            <td>0.3</td>
            <td>adamax</td>
            <td>32</td>
            <td>0,8832</td>
            <td>0,8808</td>
        </tr>
    </table>
    """, unsafe_allow_html=True)


elif option == 'Clickbait Detection':
    st.title("""Clickbait Detection""") #menampilkan judul halaman 

    title_input = st.text_input('Masukkan Judul Berita', '')
    content_input = st.text_input('Masukkan Isi Berita', '')

    def cleaning_text(text):
        # Menghilangkan baris baru, tab, underline.
        text = text.replace('\\t'," ").replace('\\n'," ").replace('\\u'," ").replace('\\',"")
        # Remove Punctuation 
        text = re.sub(r'[^\w\s]', '', text)
        # # Ambil 3 Kalimat
        # text = ' '.join(re.split(r'(?<=[.:;])\s', text)[:3])
        # Menghilangkan simbol emoticon dan huruf selain ascii
        text = text.encode('ascii', 'replace').decode('ascii')
        # Menghapus mention (@), link, dan hashtag
        text = ' '.join(re.sub("([@#][A-Za-z0-9]+)|(\w+:\/\/\S+)"," ", text).split())
        # remove_empty_space
        text = re.sub(r'', '', text.strip())
        # remove number
        text = re.sub("\d+", "", text)
        #remove multiple space
        text = re.sub(r'\s\s+', ' ', text)
        # remove incomplete URL
        return text.replace("http://", " ").replace("https://", " ")

    def tokenization(text):
        text = re.split('\W+', text)
        return text

    def remove_stopwords(text):
        stopword = nltk.corpus.stopwords.words('indonesian')
        stopword = [e for e in stopword if e not in ('akankah', 'apa', 'apakah', 'bagaimana', 'bagaimanakah', 'beberapa', 'begini', 'beginilah', 'benarkah', 'berapa', 'berapakah', 'berikut', 'bisakah', 'bolehkah', 'cara', 'hal', 'ini', 'inikah', 'inilah', 'kapan', 'kapankah', 'kok', 'mengapa', 'menurut', 'mungkinkah', 'pentingnya', 'siapa', 'siapakah', 'waduh', 'wah')]
        text = [word for word in text if word not in stopword]
        return text

    if st.button("Submit",key=0):
        if 'covid' or 'COVID' or 'Covid' in content_input :
            judul = cleaning_text(title_input)
            content = cleaning_text(content_input)

            judul = tokenization(judul.lower())
            content = tokenization(content.lower())

            judul = remove_stopwords(judul)
            content = remove_stopwords(content)

            # judul = stemmed_wrapper(judul)
            # content = stemmed_wrapper(content)

            judul = " ".join(judul)
            content = " ".join(content)

            clean_judul = [" ".join(judul.split())]
            clean_content = [" ".join(content.split())]

            # Load Model
            path = 'idwiki_word2vec200.model'
            id_w2v = gensim.models.word2vec.Word2Vec.load(path)

            df_train = pd.read_csv("df_train.csv", encoding="latin-1")
            df_test = pd.read_csv("df_test.csv", encoding="latin-1")

            MAX_LEN = 392
            for doc in df_train["Judul"]+df_train["Isi Berita"]:
                tokens = nltk.word_tokenize(doc)

            all_texts = df_train["Judul"].tolist() + df_train["Isi Berita"].tolist()

            tokenizer = Tokenizer()
            tokenizer.fit_on_texts(all_texts)

            title_train = tokenizer.texts_to_sequences(df_train["Judul"].tolist())
            content_train = tokenizer.texts_to_sequences(df_train["Isi Berita"].tolist())

            title_test = tokenizer.texts_to_sequences(df_test["Judul"].tolist())
            content_test = tokenizer.texts_to_sequences(df_test["Isi Berita"].tolist())

            title_train = pad_sequences(title_train, MAX_LEN)
            content_train = pad_sequences(content_train, MAX_LEN)

            title_test = pad_sequences(title_test, MAX_LEN)
            content_test = pad_sequences(content_test, MAX_LEN)

            vocab_size = len(tokenizer.word_index) + 1
            DIM = 200
            vocab = tokenizer.word_index
            # w2v_model = gensim.models.Word2Vec(sentences_split, size=DIM, min_count =1, window=5)
            path = 'idwiki_word2vec200.model'
            w2v_model = gensim.models.word2vec.Word2Vec.load(path)
            def get_weight_matrix(model):
                weight_matrix = np.zeros((vocab_size, DIM))
                for word, i in vocab.items():
                    try:
                        vec = model.wv[word]
                    except:
                        vec = None
                    if vec is not None:
                        weight_matrix[i] = vec
                return weight_matrix
            embedding_vectors = get_weight_matrix(w2v_model)

            clean_judul = tokenizer.texts_to_sequences(clean_judul)
            clean_judul = pad_sequences(clean_judul,maxlen=35)

            clean_content = tokenizer.texts_to_sequences(clean_content)
            clean_content = pad_sequences(clean_content,maxlen=35)

            model = tf.keras.models.load_model('modelfinal.hdf5')

            coba_predicted = model.predict([clean_judul, clean_content])
            st.write("hasil predict ", coba_predicted)

            if coba_predicted[0][0] < 0.5:
                clickbait = '<p style=" color:Red; font-size: 20px;">CLICKBAIT!</p>'
                st.markdown(clickbait, unsafe_allow_html=True)
            else :
                nonclickbait = '<p style=" color:Green; font-size: 20px;">NON-CLICKBAIT!</p>'
                st.markdown(nonclickbait, unsafe_allow_html=True)
        else :
            st.write("Berita tidak mengandung kata kunci COVID")



